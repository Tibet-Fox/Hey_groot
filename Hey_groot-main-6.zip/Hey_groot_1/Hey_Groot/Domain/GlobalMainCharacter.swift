//
//  GlobalMainCharacter.swift
//  Hey_Groot
//
//  Created by 황수비 on 2023/09/09.
//

import Foundation
import UIKit

class GlobalMainCharacter {
    static let shared = GlobalMainCharacter()
    
    var systemMainImageName: String = "Character"
    
}
