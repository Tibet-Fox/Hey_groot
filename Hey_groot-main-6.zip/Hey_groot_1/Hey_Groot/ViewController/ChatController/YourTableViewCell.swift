//
//  CharacterTableViewCell.swift
//  Hey_Groot
//
//  Created by 황수비 on 2023/09/23.
//

import Foundation
import UIKit

class YourTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    

}

