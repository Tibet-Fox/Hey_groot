  본 프로젝트는 음성 챗봇형 식물 대화 어플리케이션을 개발하고자 한다.
식물과의 대화를 통해 식물에 대한 지식을 습득하여 식물 관리를 용이하게 할 수 있도록 하는 것을 목표로 한다. 

#개발환경
- OS: MacOS Monterey
- Swift version 5
- Xcode version 14.0
- Framework: Django version 3.2
- DBMS: SQLite

회의록 : https://steadfast-binder-930.notion.site/HEY-GROOT-5ccf8552cda7489cb89930e648996395?pvs=4
